package service;

import com.doc.entity.Doctor;

public interface DocService {
	public Doctor checkDoctor(int id) throws Exception;
	
}

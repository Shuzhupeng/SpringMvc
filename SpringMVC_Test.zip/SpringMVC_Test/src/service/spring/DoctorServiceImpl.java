package service.spring;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.doc.dao.DoctorDAO;
import com.doc.entity.Doctor;

import service.DocService;

@Service("docService")
public class DoctorServiceImpl implements DocService{

	@Resource(name="doctorDAO")
	@Autowired
	private DoctorDAO dao;
	
	@Override
	public Doctor checkDoctor(int id) throws Exception {
		Doctor doctor = null;
		try {
			doctor = dao.findById(id);
			if(doctor == null){
				//医生不存在
				System.out.println("医生不存在");
				return null;
			}else{
				
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return doctor;
	}

}

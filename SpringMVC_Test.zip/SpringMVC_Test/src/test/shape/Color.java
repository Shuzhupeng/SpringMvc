package test.shape;

public interface Color {
	void fill();
}

package test.shape;

public interface Shape {
	void draw();
}

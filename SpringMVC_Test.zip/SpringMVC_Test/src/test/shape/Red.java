package test.shape;

public class Red implements Color{

	@Override
	public void fill() {
		// TODO Auto-generated method stub
		System.out.println("Inside Red::fill() method");
	}

	
}

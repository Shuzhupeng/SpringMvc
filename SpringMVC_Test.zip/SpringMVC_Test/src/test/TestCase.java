package test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.doc.entity.Doctor;

public class TestCase {
	@Test
	public void test01(){
		ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
		Doctor d1 = (Doctor) ac.getBean("doctor01");
		System.out.println(d1);
		System.out.println(ac.getBean("jdbc"));
		System.out.println("x");
	}
}

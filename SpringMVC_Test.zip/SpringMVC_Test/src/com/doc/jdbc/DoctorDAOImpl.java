package com.doc.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import com.doc.dao.DoctorDAO;
import com.doc.entity.Doctor;

@Repository("doctorDAO")
public class DoctorDAOImpl implements DoctorDAO{

	@Resource(name="ds")
	private DataSource ds;
	
	
	@Override
	public Doctor findById(Integer id) throws SQLException {
		Doctor doctor = null;
		Connection conn = null;
		PreparedStatement stat = null;
		ResultSet rst = null;
		try {
			//System.out.println("000");
			conn = ds.getConnection();
			//System.out.println("111");
			stat = conn.prepareStatement("select * from doctor_info where doctor_id=?");
			stat.setInt(1, id);
			rst = stat.executeQuery();
			if(rst.next()){
				doctor = new Doctor();
				doctor.setDoctorId(rst.getInt("doctor_id"));
				doctor.setDocName(rst.getString("doctor_name"));
				doctor.setDoctorStatus(rst.getString("doctor_status"));
				doctor.setEmail(rst.getString("email"));
				doctor.setCreatime(rst.getTimestamp("creatime"));
				doctor.setDoctorPwd(rst.getString("doctor_pwd"));
				return doctor;
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw e;
		}finally{
			closeAll(conn, stat, rst);
		}
		return doctor;
	}


	@Override
	public List<Doctor> findAllDoctor() throws SQLException {
		List<Doctor> list = new ArrayList<Doctor>();
		Connection conn = null;
		PreparedStatement stat = null;
		ResultSet rst = null;
		try {
			//打桩
//			System.out.println("before findAllDoctor");
			conn = ds.getConnection();
//			System.out.println("after findAllDoctor");;
			stat = conn.prepareStatement("select * from doctor_info order by doctor_id");
			rst = stat.executeQuery();
			while(rst.next()){
				Doctor d = createDoctor(rst);
				list.add(d);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new RuntimeException("查询失败",e);
		}finally{
			closeAll(conn, stat, rst);
		}
		return list;
	}
	
	public static void closeAll(Connection conn,PreparedStatement p,ResultSet r) {
	try{
		
		if(r!=null){
			r.close();
		}
		if(p!=null){
			
			p.close();
		}
		if(conn!=null){
			conn.close();
		}
	}catch(Exception e){}
		
	}


	private Doctor createDoctor(ResultSet rs) throws SQLException{
		Doctor d = new Doctor();
		d.setDocName(rs.getString("doctor_name"));
		d.setDoctorId(rs.getInt("doctor_id"));
		d.setDoctorPwd(rs.getString("doctor_pwd"));
		d.setEmail(rs.getString("email"));
		d.setDoctorStatus(rs.getString("doctor_Status"));
		d.setCreatime(rs.getTimestamp("creatime"));
		return d;
		
	}


	@Override
	public void deleteById(int id) {
		Doctor doctor = null;
		Connection conn = null;
		PreparedStatement stat = null;
		ResultSet rst = null;
		try {
			conn = ds.getConnection();
			stat = conn.prepareStatement("delete from doctor_info where doctor_id=?");
			stat.setInt(1, id);
			stat.executeUpdate();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new RuntimeException("根据id删除出错",e);
		}finally{
			closeAll(conn, stat, rst);
		}
		
	}


	@Override
	public void addDoctor(Doctor d) {
		Connection conn = null;
		PreparedStatement stat = null;
		ResultSet rst = null;
		try {
			conn = ds.getConnection();
			
			Date date = new Date();
//			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd kk:mm:ss");
			String time = format.format(date);
//			Date date1 = format.parse(time);
//			Timestamp ts = new Timestamp(date1.getTime());
			//
			stat = conn.prepareStatement("insert into doctor_info (doctor_name,doctor_id,doctor_status,email,doctor_pwd,creatime) value(?,?,?,?,?,?)");
			stat.setString(1, d.getDocName());
			stat.setObject(2, d.getDoctorId());
			stat.setObject(3, d.getDoctorStatus());
			stat.setString(4, d.getEmail());
			stat.setString(5, d.getDoctorPwd());
			stat.setString(6, time);
//			stat.setTimestamp(6, ts);
			stat.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new RuntimeException("增加医生失败",e);
		}finally{
			closeAll(conn, stat, rst);
		}
	}

}

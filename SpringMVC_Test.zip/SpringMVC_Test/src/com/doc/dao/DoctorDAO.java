package com.doc.dao;

import java.sql.SQLException;
import java.util.List;

import com.doc.entity.Doctor;

public interface DoctorDAO {
	public Doctor findById(Integer id) throws SQLException;
	
	public List<Doctor> findAllDoctor() throws SQLException;
	
	public void deleteById(int id);
	
	public void addDoctor(Doctor d);
}

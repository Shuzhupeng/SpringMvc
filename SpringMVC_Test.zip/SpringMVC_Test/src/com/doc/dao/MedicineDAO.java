package com.doc.dao;

import java.sql.SQLException;

import com.doc.entity.Doctor;

public interface MedicineDAO {
	public Doctor findById(Integer id) throws SQLException;
}

package com.doc.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.doc.dao.DoctorDAO;
import com.doc.entity.Doctor;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import service.DocService;

@Controller
public class DoctorController {
	@Resource(name="docService")
	@Autowired
	private DocService service;
	@Resource(name="doctorDAO")
	@Autowired
	private DoctorDAO doctorDao;
	
	@RequestMapping("/login.do")
	//鏌ヨ锛岃烦杞埌鏄剧ず椤甸潰
	public String toAdd(){
		//System.out.println("toAdd");
		return "login";
	}
	
	
	@RequestMapping("/find.do")
	public String find(HttpServletRequest req,HttpServletResponse res){
		try {
			//1.鑾峰彇琛ㄥ崟涓殑鏁版嵁
			req.setCharacterEncoding("utf-8");
			String id = req.getParameter("docId");
			
			//鍒ゆ柇鏍规嵁id鏌ユ壘鐨勫尰鐢熸槸鍚﹀瓨鍦�
			Doctor doctor = service.checkDoctor(Integer.parseInt(id));
			if(doctor==null){
				return "repeat_error";
			}
			String doctorName = doctor.getDocName();
			int doctorId = doctor.getDoctorId();
			String email = doctor.getEmail();
			
			doctor.setDocName(doctorName);
			doctor.setDoctorId(doctorId);
			doctor.setEmail(email);
			
			req.setAttribute("docs", doctor);
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return "find_doc";
		
	}
	
	@RequestMapping("/findAll.do")
	//鏄剧ず椤甸潰
	public String Show(HttpServletRequest req,HttpServletResponse res){
		
		try {
			List<Doctor> list = doctorDao.findAllDoctor();
			//鎵撴々
			for(Doctor l:list){
				System.out.println(l);
			}
			req.setAttribute("lists", list);
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "findAll";
	}
	
	@RequestMapping("/deleteDoctor.do")
	public String deleteDoctor(HttpServletRequest req,HttpServletResponse res){
		String id = req.getParameter("doctorId");
		doctorDao.deleteById(Integer.parseInt(id));
		return "redirect:findAll.do";
	}
	
	@RequestMapping("/toAddDoctor.do")
	public String toAddDoctor(HttpServletRequest req,HttpServletResponse res){
		return "addDoctor";
//		return "WebContext/index";
	}
	
	@RequestMapping("/addDoctor.do")
	public String addDoctor(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException{
		req.setCharacterEncoding("utf-8");
		String name = req.getParameter("docName");
		//鎵撴々
//		System.out.println(name);
		String id = req.getParameter("doctorId");
		String status = req.getParameter("doctorStatus");
		String email = req.getParameter("email");
		String pwd = req.getParameter("doctorPwd");
		
		System.out.println(id);
		
		Doctor d = new Doctor();
		d.setDocName(name);
		d.setDoctorId(Integer.parseInt(id));
		d.setDoctorStatus(status);
		d.setEmail(email);
		d.setDoctorPwd(pwd);
		
		doctorDao.addDoctor(d);
		
		return "redirect:findAll.do";
	}
	
	//浣跨敤Json
	@RequestMapping("/findAll_json.do")
	public JSONObject findAll_json(HttpServletRequest req,HttpServletResponse res) throws NumberFormatException, Exception{

		String message = null;
		JSONObject jsonObject =null;
		JSONObject json = null;
		List<Doctor> lists = null;
		
		
		try {
			req.setCharacterEncoding("utf-8");
			String id = req.getParameter("docId");

			jsonObject = new JSONObject();
			Doctor doctor = service.checkDoctor(Integer.parseInt(id));
			System.out.println(doctor);
			//2
			json = JSONObject.fromObject(doctor);
			System.out.println(json);
			
//			res.getWriter().write(json.toString());
			
		req.setAttribute("aaa", json.toString());
			
//			// 鍒╃敤dao鑾峰彇鏁版嵁
//			lists = new ArrayList<Doctor>();
//			lists = doctorDao.findAllDoctor();
//			
//			jsonObject.put("categorys", lists);
//			if(lists!=null && lists.size()>0){
//				JSONArray jsonArray = new JSONArray();
//				jsonArray.fromObject(lists);
//				message = jsonArray.toString();
//				//鎵撴々
//				System.out.println("jsonArray:"+jsonArray);
//				System.out.println("jsonArray_toString():"+message);
//				//鍐欏叆鍒板墠鍙�
//				res.getWriter().write(message);
//			}else{
//				//鎵撴々
//				System.out.println(lists.size());
//			}
			
		} catch (Exception e) {
			e.printStackTrace();		
		}
		return json;
	}
	
	
}

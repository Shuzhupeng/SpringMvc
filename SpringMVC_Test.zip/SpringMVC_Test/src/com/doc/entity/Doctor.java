package com.doc.entity;

import java.sql.Timestamp;

import org.springframework.stereotype.Component;

@Component
public class Doctor {
	private Integer doctorId;
	private String docName;
	private String doctorPwd;
	private String doctorStatus;
	private String email;
	private Timestamp creatime;
	public Doctor(){
		
	}
	public Doctor(Integer doctorId, String docName, String doctorPwd,
			String doctorStatus, String email, Timestamp creatime) {
		super();
		this.doctorId = doctorId;
		this.docName = docName;
		this.doctorPwd = doctorPwd;
		this.doctorStatus = doctorStatus;
		this.email = email;
		this.creatime = creatime;
	}
	public Integer getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(Integer doctorId) {
		this.doctorId = doctorId;
	}
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public String getDoctorPwd() {
		return doctorPwd;
	}
	public void setDoctorPwd(String doctorPwd) {
		this.doctorPwd = doctorPwd;
	}
	public String getDoctorStatus() {
		return doctorStatus;
	}
	public void setDoctorStatus(String doctorStatus) {
		this.doctorStatus = doctorStatus;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Timestamp getCreatime() {
		return creatime;
	}
	public void setCreatime(Timestamp creatime) {
		this.creatime = creatime;
	}
	@Override
	public String toString() {
		return "Doctor [doctorId=" + doctorId + ", docName=" + docName
				+ ", doctorPwd=" + doctorPwd + ", doctorStatus=" + doctorStatus
				+ ", email=" + email + ", creatime=" + creatime + "]";
	}
	
	
	
}

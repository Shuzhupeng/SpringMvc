/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50515
Source Host           : localhost:3306
Source Database       : db_spring

Target Server Type    : MYSQL
Target Server Version : 50515
File Encoding         : 65001

Date: 2016-09-16 11:20:37
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for doctor_info
-- ----------------------------
DROP TABLE IF EXISTS `doctor_info`;
CREATE TABLE `doctor_info` (
  `doctor_id` int(4) NOT NULL,
  `doctor_name` varchar(8) DEFAULT NULL,
  `doctor_status` varchar(1) DEFAULT NULL,
  `doctor_pwd` varchar(255) DEFAULT NULL,
  `creatime` datetime DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`doctor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of doctor_info
-- ----------------------------
INSERT INTO `doctor_info` VALUES ('1001', '舒鹏', '1', 'haha', '2016-09-15 09:00:23', 'shupeng@qq.com');
INSERT INTO `doctor_info` VALUES ('10012', '1', '1', '1', '2016-09-16 09:43:21', '1');
INSERT INTO `doctor_info` VALUES ('10013', 'haha', '1', 'fdaf', '2016-09-16 10:46:54', 'fdsa@qq.com');
INSERT INTO `doctor_info` VALUES ('10014', 'nicolas', '1', 'fa', '2016-09-16 11:12:28', 'sf@qq.com');
INSERT INTO `doctor_info` VALUES ('10015', 'Alice', '2', 'fa', '2016-09-16 11:14:25', 'fas@qq.com');
INSERT INTO `doctor_info` VALUES ('10016', 'Alice2', '2', 'fad', '2016-09-16 11:15:49', 'dfs@qq.com');
